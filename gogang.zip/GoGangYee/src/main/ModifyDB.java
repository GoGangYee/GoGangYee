package main;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

public class ModifyDB extends JFrame{
	String[] region = {"������","�������","������","�����Ϸ�","���ϱ�","������","���״��","���Ǳ�","���ǻ�","������","���α�","�õ�","��õ��","����","�����","������","������","���빮��","���۱�","������","���빮��","���۱�","���۴��","������","���ѻ�","���빮��","���ʱ�","������","���ϱ�","����","���ı�","������","���̷�","��õ��","��������","��������","��걸","����","������","����","���α�","�߱�","�߶���","õȣ���","û��õ��","�Ѱ����","����","ȫ����","ȭ����"};
	ButtonGroup radioBtns=new ButtonGroup();	//���� �ߺ� ���� ���� ���� ���� ��ư
    JRadioButton ck1 = new JRadioButton("�̻�ȭ����");
    JRadioButton ck2 = new JRadioButton("�ϻ�ȭ���");
    JRadioButton ck3 = new JRadioButton("��Ȳ�갡��");
    JRadioButton ck4 = new JRadioButton("����");
    JRadioButton ck5 = new JRadioButton("�̼�����");
    JRadioButton ck6 = new JRadioButton("�ʹ̼�����");
    JButton apply = new JButton("��ȸ");
    JTextField t3 = new JTextField(10); // ������ ������ �Է� ����
    JTextField t1 = new JTextField(2); // �� �Է�
    JTextField t2 = new JTextField(2); // �� �Է�
    JComboBox<String> cb = new JComboBox<>(region);
    JTextArea textArea = new JTextArea(1, 10);
    
      ModifyDB() {
         setTitle("������");
         
         setLayout(new BorderLayout(10,10));
         showNorth();
         showWest();
         showEast();
         
         setSize(800, 500);
         setVisible(true);
         
      }
      void showNorth() {
         JPanel p1 = new JPanel();
         JPanel panel = new JPanel(new FlowLayout());
         
         JLabel lbl1 = new JLabel("���� �� ����");
         lbl1.setFont(new Font("��������", Font.PLAIN, 30));
         p1.add(lbl1);
         panel.add(p1);
         
         add(panel, BorderLayout.NORTH);
      }
      void showWest() {
        JPanel p1 = new JPanel(new BorderLayout()); // ������¥���� + ��������
         JPanel p2 = new JPanel(new BorderLayout()); // �������� + ��¥����
         JPanel p3 = new JPanel(new FlowLayout(FlowLayout.LEFT)); // ��������
         JPanel p4 = new JPanel(new FlowLayout(FlowLayout.LEFT)); // ��¥����
         JPanel p4_1 = new JPanel(new FlowLayout());
         JPanel p5 = new JPanel(new BorderLayout()); // ��������
         JPanel p6 = new JPanel(); // ���� ���� ���� ��ư
         JPanel p7 = new JPanel(new GridLayout(1,2)); // ���� ���� �ڽ� ����
         JPanel p7_0 = new JPanel(new FlowLayout(FlowLayout.CENTER)); // �������ö�
         JPanel p7_1 = new JPanel(new BorderLayout());
         JPanel p7_2 = new JPanel(new BorderLayout());
         JPanel ppmPanel = new JPanel(new BorderLayout());
         JPanel ��gPanel = new JPanel(new BorderLayout());
         JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
         
         JLabel lbl1 = new JLabel("��¥ ����");
         JLabel lbl2 = new JLabel("���� ����");
         JLabel lbl3 = new JLabel("2018��");
         JLabel month = new JLabel("��");
         JLabel day = new JLabel("��");
         JLabel lbl4 = new JLabel("���� ����");
         
         
         cb.setPreferredSize(new Dimension(200,25));
         
         
         
         Box ppm = Box.createVerticalBox();
         Box ��g = Box.createVerticalBox();
         
         radioBtns.add(ck1);
         radioBtns.add(ck2);
         radioBtns.add(ck3);
         radioBtns.add(ck4);
         radioBtns.add(ck5);
         radioBtns.add(ck6);
         
         ppmPanel.setBorder(new TitledBorder(new EtchedBorder(), " ppm "));
         ��gPanel.setBorder(new TitledBorder(new EtchedBorder(), " ��g "));
         p1.setBorder(BorderFactory.createEmptyBorder(0, 70, 0, 0));
         
         panel.add(p1);
         
         p1.add(p2, BorderLayout.NORTH);
         p1.add(p5, BorderLayout.CENTER);
         
         p2.add(p3, BorderLayout.NORTH);
         p2.add(p4, BorderLayout.CENTER);
         p3.add(lbl2);
         p3.add(cb);
         p4.add(lbl1);
         p4.add(p4_1);
         p4_1.add(lbl3);
         p4_1.add(t1);
         p4_1.add(month);
         p4_1.add(t2);
         p4_1.add(day);
         
         p5.add(p7_0, BorderLayout.NORTH);
         p5.add(p7, BorderLayout.CENTER);
         p5.add(apply, BorderLayout.SOUTH);
         p7.add(p7_1);
         p7.add(p7_2);
         p7_0.add(lbl4);
         p7_1.add(ppmPanel, BorderLayout.CENTER);
         p7_2.add(��gPanel, BorderLayout.CENTER);
         
         ppmPanel.add(ppm, BorderLayout.CENTER);
         ppm.add(Box.createVerticalStrut(15));
         ppm.add(ck1);
         ppm.add(ck2);
         ppm.add(ck3);
         ppm.add(ck4);

         ��gPanel.add(��g, BorderLayout.CENTER);
         ��g.add(Box.createVerticalStrut(15));
         ��g.add(ck5);
         ��g.add(ck6);
         
         add(panel, BorderLayout.WEST);
      }
      void showEast() {
         JPanel p1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
         JPanel p2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
         JPanel p3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
         JPanel panel = new JPanel(new GridLayout(3,1));
         
         
         JLabel l1 = new JLabel("����/������ �������Դϴ�.");
         JLabel l2 = new JLabel("���ο� �����͸� �Է��ϼ���.");
         JLabel l3 = new JLabel("�����͸� �����Ϸ��� Ŭ���ϼ���.");
         
         JButton b1 = new JButton("����");
         JButton b2 = new JButton("����");
         
         textArea.setEditable(false);
         panel.setBorder(BorderFactory.createEmptyBorder(50, 10, 150, 10));
         
         p1.add(l1);
         p1.add(textArea);
         p2.add(l2);
         p2.add(t3);
         p2.add(b1);
         p3.add(l3);
         p3.add(b2);
         panel.add(p1);
         panel.add(p2);
         panel.add(p3);
         
         add(panel, BorderLayout.CENTER);
         
         apply.addActionListener(new ActionListener() {
   			public void actionPerformed(ActionEvent e) {
   				String material="";
   				String data="";
   				Connection conn=null;
   				Statement stmt=null;
   				ResultSet rs=null;
   				String url="jdbc:mysql://localhost/gogang?characterEncoding=UTF-8&serverTimezone=UTC";
   				
   				if(ck1.isSelected())
   				{
   					material="no2";
   				}
   				if(ck2.isSelected())
   				{
   					material="o3";
   				}
   				if(ck3.isSelected())
   				{
   					material="co2";
   				}
   				if(ck4.isSelected())
   				{
   					material="so2";
   				}
   				if(ck5.isSelected())
   				{
   					material="microdust";
   				}
   				if(ck6.isSelected())
   				{
   					material="ultrafinemicrodust";
   				}
   				
   				data=material+"=";
   				
   				try {
   					Class.forName("com.mysql.cj.jdbc.Driver");
   					
   					conn=DriverManager.getConnection(url,"root","Pringle!135");
   					//����
   					stmt=conn.createStatement();
   					
   					String sql="select "+material+" from gogang where "+"date='"+"2018"+t1.getText()+t2.getText()
   		  					+"' and local='"+cb.getSelectedItem().toString()+"'";
   					
   					System.out.println(sql);
   					rs=stmt.executeQuery(sql);	
   					
   					if(rs.next())
   					{
   						data+=rs.getString(material);
   						if(data.equals(""))
   						{
   							data="0";
   						}
   					}
				    
   					System.out.println(data);
   				}
   				catch(ClassNotFoundException e1) {
   					System.out.println("����̹� �ε� ����");
   				}
   				catch(SQLException e1) {
   					System.out.println("����: "+e1);
   				}
   				finally {
   					textArea.setText(data);
   					try {
   						if(conn !=null && !conn.isClosed()) {
   							conn.close();
   						}
   					}
   				
   				catch(SQLException e1) {
   					e1.printStackTrace();
   				}
   				}
   			}
   		});
         
         b1.addActionListener(new ActionListener() {
  			public void actionPerformed(ActionEvent e) {
  				String material="";
  				Connection conn=null;
  				Statement stmt=null;
  				int rs=0;
  				String url="jdbc:mysql://localhost/gogang?characterEncoding=UTF-8&serverTimezone=UTC";
  				
  				if(ck1.isSelected())
   				{
   					material="no2";
   				}
   				if(ck2.isSelected())
   				{
   					material="o3";
   				}
   				if(ck3.isSelected())
   				{
   					material="co2";
   				}
   				if(ck4.isSelected())
   				{
   					material="so2";
   				}
   				if(ck5.isSelected())
   				{
   					material="microdust";
   				}
   				if(ck6.isSelected())
   				{
   					material="ultrafinemicrodust";
   				}
  				
  				try {
  					Class.forName("com.mysql.cj.jdbc.Driver");
  					
  					conn=DriverManager.getConnection(url,"root","Pringle!135");
  					//����
  					stmt=conn.createStatement();
  					
  					String sql="update gogang set "+material+"="+t3.getText()+" where date='2018"+t1.getText()+t2.getText()
  					+"' and local='"+cb.getSelectedItem().toString()+"'";
  					
  					System.out.println(sql);
  					rs=stmt.executeUpdate(sql);
  					
  				}
  				catch(ClassNotFoundException e1) {
  					System.out.println("����̹� �ε� ����");
  				}
  				catch(SQLException e1) {
  					System.out.println("����: "+e1);
  				}
  				finally {
  					try {
  						if(conn !=null && !conn.isClosed()) {
  							conn.close();
  						}
  					}
  				
  				catch(SQLException e1) {
  					e1.printStackTrace();
  				}
  				}
  			}
  		});
         
         b2.addActionListener(new ActionListener() {
   			public void actionPerformed(ActionEvent e) {
   				String material="";
   				Connection conn=null;
   				Statement stmt=null;
   				int rs=0;
   				String url="jdbc:mysql://localhost/gogang?characterEncoding=UTF-8&serverTimezone=UTC";
   				
   				if(ck1.isSelected())
    				{
    					material="no2";
    				}
    				if(ck2.isSelected())
    				{
    					material="o3";
    				}
    				if(ck3.isSelected())
    				{
    					material="co2";
    				}
    				if(ck4.isSelected())
    				{
    					material="so2";
    				}
    				if(ck5.isSelected())
    				{
    					material="microdust";
    				}
    				if(ck6.isSelected())
    				{
    					material="ultrafinemicrodust";
    				}
   				
   				try {
   					Class.forName("com.mysql.cj.jdbc.Driver");
   					
   					conn=DriverManager.getConnection(url,"root","Pringle!135");
   					//����
   					stmt=conn.createStatement();
   					
   					String sql="update gogang set "+material+"=0"+" where date='2018"+t1.getText()+t2.getText()
   					+"' and local='"+cb.getSelectedItem().toString()+"'";
   					
   					System.out.println(sql);
   					rs=stmt.executeUpdate(sql);
   					
   				}
   				catch(ClassNotFoundException e1) {
   					System.out.println("����̹� �ε� ����");
   				}
   				catch(SQLException e1) {
   					System.out.println("����: "+e1);
   				}
   				finally {
   					try {
   						if(conn !=null && !conn.isClosed()) {
   							conn.close();
   						}
   					}
   				
   				catch(SQLException e1) {
   					e1.printStackTrace();
   				}
   				}
   			}
   		});
      }
   }