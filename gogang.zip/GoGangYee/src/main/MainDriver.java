package main;

public class MainDriver {

	public static void main(String[] args) {
		new MainView();
	
	}

}
